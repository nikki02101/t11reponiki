
//1es feladat
function PhErtek(vizsgaltErtek) {
    if (vizsgaltErtek == 7) {
        return "semleges";
    }
    else if (vizsgaltErtek < 7) {
        return "savas";
    }
    else {
        return "lugos";
    }
}
//2es feladat
function PrimekSzama(vizsgaltTomb) {
    var primDbSzama = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        var osztokSzama = 0;
        for (var j = 1; j <= vizsgaltTomb[i]; j++) {
            if (vizsgaltTomb[i] % j == 0) {
                osztokSzama++;
            }
        }
        if (osztokSzama == 2) {
            primDbSzama++;
        }
    }
    return primDbSzama;
}
//3as feladat
function MaganHangzokSzama(vizsgaltSzoveg) {
    var maganHangzok = ["A", "Á", "E", "É", "I", "Í", "O", "Ó", "Ö", "Ő", "U", "Ú", "Ü", "Ű", "a", "á", "e", "é", "i", "í", "o", "ó", "ö", "ő", "u", "ú", "ü", "ű"];
    var darab = 0;
    for (var i = 0; i < maganHangzok.length; i++) {
        for (var j = 0; j < vizsgaltSzoveg.length; j++) {
            if (vizsgaltSzoveg[j] == maganHangzok[i]) {
                darab++;
            }
        }
    }
    return darab;
}
