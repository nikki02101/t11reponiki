export{};

//1es feladat

function PhErtek(vizsgaltErtek:number):string {
    if (vizsgaltErtek == 7) {
        return "semleges";
    }
    else if (vizsgaltErtek < 7) {
        return "savas";
    }
    else {
        return "lugos"
    }
}

//2es feladat

function PrimekSzama(vizsgaltTomb:number[]):number {
    let primDbSzama:number = 0;
    for (let i:number = 0; i < vizsgaltTomb.length; i++) {
      let osztokSzama:number = 0;
      for (let j:number = 1; j <= vizsgaltTomb[i]; j++) {
        if (vizsgaltTomb[i] % j == 0) {
          osztokSzama++;
        }
      }
      if (osztokSzama == 2) {
        primDbSzama++;
      }
    }
    return primDbSzama;
  }



//3as feladat
function MaganHangzokSzama(vizsgaltSzoveg:string):number {
    let maganHangzok:string[] = ["A", "Á", "E", "É", "I", "Í", "O", "Ó", "Ö", "Ő", "U", "Ú", "Ü", "Ű", "a", "á", "e", "é", "i", "í", "o", "ó", "ö", "ő", "u", "ú", "ü", "ű"];
    let darab:number = 0;
    for (let i:number = 0; i < maganHangzok.length; i++) {
        for (let j:number = 0; j < vizsgaltSzoveg.length; j++) {
            if (vizsgaltSzoveg[j] == maganHangzok[i]) {
                darab++
            }
        }
    }
    return darab;

}
